var lastdata;

var editProfile = function(data){
    var summaryText = $('.summary p').text().trim();
    $('.summary p').remove();
    $('.summary').append('<textarea id="summaryText"class="form-control">' + summaryText + '</textarea>');
}

var saveProfile = function(data){
    var summaryText = $('.summary textarea').val();
    $('.summary textarea').remove();
    $('.summary').append('<p>' + summaryText + '</p>');

    lastdata[0].Description = summaryText;
    postProfile();
}

var postProfile = function(){
    $.ajax({
        url: "../api/SaveProfile",
        type: 'POST',
        data: JSON.stringify(lastdata),
        contentType: 'application/json; charset=utf-8',
        dataType : 'json',
        asyn : false,
        success: function(data){

        }
    })
}

$('#savebtn').click(saveProfile);
$('#editbtn').click(editProfile);

