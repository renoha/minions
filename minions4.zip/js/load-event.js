var loadEvent = function(data){
    var events = "";
    for(var i=0; i<data.length;i++){
        var event = data[i];
        var tags = "";
        for(var j=0; j<event.Tags.length;j++){
            tags += '<a style="cursor:pointer">' + event.Tags[j] + ' </a>';
        }
        events += '<article class="white-panel"><img src="' +event.Picture  + '" alt="">' +
            '<h4><a href="#">' + event.Title + '</a></h4>'+
            '<p><small class="text-muted"><i class="fa fa-clock-o"></i>' +  event.Time + ' </small>'+
            '<small class="text-muted"><i class="fa fa-th-large"></i>' +  event.Location + '</small> <br>' +
            '<small class="text-muted"><i class="fa fa-star"></i>' + tags + '</small>' +
            '</p>' + '<p>' + event.Content + '</p></article>';
    }
    $('#pinBoot').html(events);
}

var updateProfile = function(){
    $.get( "GetEvent/", function( data ) {
        loadEvent(data);
    });
}
