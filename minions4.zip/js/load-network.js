
var nodes = null;
var edges = null;
var network = null;

// Called when the Visualization API is loaded.
function draw(dataArr1, dataArr2) {
    setupNodes(dataArr1, dataArr2);
    setupEdges(dataArr1, dataArr2);

    // create a network
    var container = document.getElementById('mynetwork');
    var data = {
        nodes: nodes,
        edges: edges
    };
    var options = {
        nodes: {
            borderWidth: 4,
            size: 50,
            color: {
                border: '#222222',
                background: '#666666'
            },
            font: {color: '#eeeeee'}
        },
        edges: {
            color: 'lightgray'
        }
    };
    network = new vis.Network(container, data, options);
}

function setupNodes(dataArr1, dataArr2){

    nodes = [];
    for(var i = 0;i<dataArr1.length;i++){
        var data = dataArr1[i];
        var node = {
            id: data.MPid,
            shape: 'circularImage',
            image: data.Picture,
            label: data.FirstName
        }
        nodes.push(node);
    }
    if(dataArr2.length >= 2) {
        for (var i = 0; i < dataArr2.length - 1; i++) {
            var data = dataArr2[i];
            var node = {
                id: data.MPid,
                shape: 'circularImage',
                image: data.Picture,
                label: data.FirstName
            }
            nodes.push(node);
        }
    }
}

function setupEdges(dataArr1, dataArr2){
    if(dataArr1.length>=2) {
        for (var i = 1; i < dataArr1.length; i++) {
            var fromdata = dataArr1[i-1];
            var todata = dataArr1[i];
            var edge = {
                from: fromdata.MPid,
                to: todata.MPid
            }
            edges.push(edge);
        }
    }
    if(dataArr2.length >= 2) {
        for (var i = 1; i < dataArr2.length - 1; i++) {
            var fromdata = dataArr1[i-1];
            var todata = dataArr1[i];
            var edge = {
                from: fromdata.MPid,
                to: todata.MPid
            }
            edges.push(edge);
        }
    }
}


function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return pair[1];
        }
    }
}

var updateConnection = function () {
    var id = getQueryVariable("id");
    var VanessaMPid = "M834157";
    $.get("GetConnection/" + VanessaMPid + "/" + id, function (data) {
        draw(data.SourceConnectionPath, data.DestConnectionPath);
    });
}

$(document).ready(function(){
    updateConnection();
});

